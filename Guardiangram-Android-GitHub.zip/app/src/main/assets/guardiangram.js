(() => {
  const GUARDIAN_AVATAR = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCACgAJ4DASIAAhEBAxEB/8QAHQAAAAcBAQEAAAAAAAAAAAAAAAECAwUGBwQICf/EADkQAAEDAwMCBAQEBAUFAAAAAAECAwQABREGEiExQQcTIlEUYXGBCDJCwSNSkaEVcrHR8CREYpLx/8QAGgEAAQUBAAAAAAAAAAAAAAAAAQACAwQFBv/EAC4RAAICAgECBAUEAgMAAAAAAAECAAMEESESMQUTQVEiYXGBkRUjodEUMkLh8P/aAAwDAQACEQMRAD8A8D0XagOlAVvyGAdKBo6I0oRCoxRUpCFOLCUJKiegHegIYKLHFSbdpdQA5PUiK11/iKwo/RPX+1JmvWgKKIEV5QAxvdX1P0FPK8cyIWAnS8yNrogwJlyntQbfGckyHVbW2m07lKPsBTKUFawlIKiTgAd69X+CHhWxpuxN6lvkYLuspIU02tOTHT2+ijTfmZBmZa46dXr6TzDcbS9Zri7b7sFMTGVbXWEgKKD7E5xmpfRmno19nS1Sm1qjx2txAXglWePt1rVJfgnOneLd2k3t9w2hTpfbe3ZW/u5257Ed6hLvqTRmjp6dO2SEqUGElt6YlQySeoz+rmpEUb2e0zcnxBrajVjAlyPT0mV3qMzDv0qMwkpbQshIJzgVwVJX87tSTFdi4SPpUbUbdzNmgk1rvvoQUYoqA4oSWHQoDnmhmjBBQHSj7UXSlFAOBQwaMe9FmlFDobST7Z96Ap53DkZDg/Mn0K/b/nypQSWes1utbLDtzuIfU4Ar4eFgnb81ngd+xq53PS9vunh9DvPh3b5iwzuFw3ObnUEAdf7nisyabdffSyyhTi1HalI5Jr0T4B2S/WNd3ZvFvcixnwgo80DClDOcfY04H2Ey852oQOX+IHt239p50WpxSypxSlKzyVHmk1uPjB4SwbHbH9VWN7a0XcyIyiMJ3Hqn79qw6mS7iZKZFfWkeiyXokxqVHWUOtKC0K9iDkGvXLvjBE054LWHUN6YU9cpzWERW1AFwjgrPsP968gDirHDQ7fNJSGZd5Df+Eo8yNHePpUlSvUEn3zjinLzxIM7FS3pZ+wPP/vrLNqjxs1bqNxKW1NW9pDpcQI4O7HYKPes4KlLcKlEkk5J96IiiFAkmWaMeukarGpL6haDcyKrGFLitKV9cY/aoirLfy3P07bLq0nBCPh3cdikcf8APnVaosOY3EYmob7jj8QUrNJox0oCWDB3oUO9HSig7UQ4odqA5pRQ6NGCrnpRpTlBPHFJHFHUEfkqYW4Sw15ScflzmmULKELQcEKGKFJNIxKNDUvnhhCgyby7JksqU9GKVtLzwOowa9DQ7sxAtDk6U6ltmO2XFEnjAFeevDhMhmU+sEFhxI/9ganPEzUbQ0+1Yo0tQfWsLebGfyY4yfr2qUaCbnHZ1T5HiflA8cfYesputNbXbV9/kS5Up4RCo+TG3HahPbj3qr0fetk8NPA86psjWpNQXEQ7U4CpCWyN6wDgkk8AcGod7nUPZTh1jfAmN4zV2g+G1/keF1y1k5BdbjR9hb3pIK0E4Use4HFeobB4MeFrjbUi226PMXHwPNDxcJUOcq5xmtEk2mJJtb1tejtrivNltbOPSUkYxigW6ePWZd3i5bXljU+ceKFTOrLexatcXa2xseTHluNIx2AUcCoalN1GDqGHrJFuQVaXeibsbH0u4J6ggj/XFR1SVjiG4XFUBJSFPtqSkq/mAyP7gVwOtOsPrZdQpC0EpUkjkGj6RiFQxUd+/wCYijHSipxtpxzPltqVgZO0ZwKG5IYjFHTiY8lbRdQw4psdVBJwPvSS2vbuKFY98U5R1A6g2IjPNGOaBQoDJBA+YounSkQR3h7w+aFCh2pQRQ6Ukj50YNErpR9IhJizagkWZCCwEqw5uUk/qGOnyrtahy9easc+DQ1HfWgKKVrJBxxkVWRWreEdqjpUu8rbX54UWm1bvTjHPFFNtwe0zPEGrxEbJUfH239ZM2z8PUiUlh2Vf20Ixl4IbyR/lrv8W9RJ0d4fWzw3sc048ofEqxhewHjn5nNaDcta2XSdiMq7SUhRRltgH1u47AV501frmLq3Xib9KsrSWUJS35BWfWkH9RH7UenXymX4e+RmOLLtsq8+nebN+FS13RmTdr0/vTBeQllrcT61A5JA6fKtq8Rtaw9B6LkX+VGcf2KDbbSOCpSumT2FZrZ/G7wr07YIUa2bmG0tozGjsEbCT6s59utaHd4en/E7w7XGbmpkW6e0NrzWCU+xGehBFMcEHqaRXuzWeZYpAJ/ieDLpPdul5l3F8kuSHVOqJ91Emm4UORcLgzBiNlx95YQhA7k16BY/DA4i7yBcNSBEAE+Sptr+Iodec8DiuK/eDqPCthGtJb9wlsQ5CUsoXGLIW9k7U5PX8p6Cgo2dTc/UaujVWyfTg/aV7RfhZqCDqEzb7DEdlhJKBvB3q7dO1J1fpyDbtSt3qTB+JiPHY+2kElJ7LAHXpXfN8Tte3qOpFvtcWClf/cOJ9QB9txx98VVX7bcZZL9+1HIeV0UkLOP6n/apwyoNTG/eN/n32Aca0O+vt2nBeU2OalmLa2mLe0klanXUFKlf7/SkWWLpZExaLnKkONJTnzWQcKOemCOmM9T2onpGm7cCGYyZDg6FR3nP+lRU28vS0hsNIaaHIQkVC6rbtW4B9pq1Vu9flr1Ae5PP9yduMu2uXBxVskvx4wTsHmEZUPp0FQbr0Btwltbq+Mc1GlaldTSa1KM+rFqFVFQ37nZ/jepaqxQg1sxa3CrPJ25zimyaOiIrMd2c9TGWhxDoYoUMZoCKCiJpSQCvClhI9z2qRhiF5iGo8N6fKUoJShQwnPb0jk0gNxpbpG4qx2tc+V/EjuKj42qcA4ST05rbdLRoVlsbbaFhphtO9S1n7kk1UXdP6x01o8XnUlreiWsLAQ02yBtJzjPsM+9Z9cb5PnqW2uY+Y+TtbUroPbiplK1iYGXi2+JN0htID9d/9zr1dfZN/wBVSpTz5caSsoYAOQlAJwBTmntA601Y6Eac0xdLjnotmOoo64/NjH96g40hUWSh5ABKVA4PQ4Of2rX5HjZ44ayaatmnn5kSM2naiPYYhb4HHKkgq4BA646VXdj3m2qGpAiAAASLvvgTqnRuljfddz7Zp9teQxFde86RIUASUpSjIz06kDmoTS/iprPRunnrNYLkliO6srytsLUgkY9O7p71dbR+H3xc1nLEu/vfBZISp67SlOu46cJG4nA9yK1nSn4PNOs7XtVainXE7RlmGgMIzjn1HJPOMdKiN6oNEyB7aiNWkN9pnsn8WGrmbXFjaa05ZbbcEsobfuTjRkPOqT3AVwnkr454V2pLt08YPEiA1P1AzdLgncFoVIR5LDZ90pOB07gdK9Wae8INAaSjhNj0rb2HE4Pnrb813IJwd6snv712Xi2sqjkKSBgYGagGQu9qJm5b1snSi9p4xl6VvcdeLhKQyO4aTuP0yeP7Vyu2WKywrKVOqUMKU6dx+3t9q9D6j0/HcbWotBSScKGKx+/234C4OsDOw+pP0rRx3Rx25nOXX21toHQ+Uwa7W5y23V2MtJ2g5QT3T2riq965hpNtYlpSMoXsJ+R/+VRKDL0kidvgZP8AkUK57wqHSjoU3UtwURo6FKIQfOpSPa0SIxCHUB4oC071hKcE/wCv9KjOlKJ4xThGsCexilRy3MXHecQkpUUlQO4ZHzHWp/SzrUDU8SRbCp+c25vaUtsbEkc7ik9cVXRU1pJ9MfV8NaxkKUUf1BFNA5kOVvyWPyMtGp42rtUSBIul9fmKJx5Tzh2J+g6Dp7VzxdDW8JxLkPrUR+ghIB/pVucUgg4TtIP9RTTePN46VOqKZyH6rkdHSp0B7Sb0TovTDKfPetDEhW4gKfHmYH0PFehNNtRExkojIQ0jGdqEhIz9qxrTqkx7e2o9Nuc1NM68btW5KHNx6D5VRuQsx6ZBXlsx3axM9HWhhC0JT296s7EdJBGOcVgei/FeO/KRHeWElXUE/vW7WC4sToxeT78k1l3KyHRm1i2JYPhMek4bbx1qqXp5Gw5x8hUxqe7NW6Ot1zCUYxmsJ1R4nxWpS2W3gRnHFClGc8RZVyVjTGWO9vMrYW2MFWMYFY3rlpI8l8deUHFTjWrG5joeDoUCecHIqF1Y4HrWpeARvBGPnWtiqUYTByLBYOJns2GxOhuRZCdzaxgjNQreibSWi2nzAQc+YpXNWJQwTz2oH8yGc443q+p6VoHQ5MFOVdUvTW2hMt1Jb2bNfXIUZfmN7UqClDnkVC1M6qf+I1XLUFEhKtg+WBUNUNjljo+k7vE6vJQv30NwUKFCo5YgyaVjIpNODpntThFE4NPQ3jHuDL4JGxYVx9abpJ6Gl2EBGxozYA7vQl0EEKTRs8n3xVes11Ltljg5J27T8iOKnWlAAjNSIZwV9BqJUy1TZarbpoY/SkA4PNQMaGubDTNuclUVpzKmkBJUpYFS8+MqdZNidxO0cjmuTWEyPcPDW2phPsxrlAQWtijjzBu5A/8ALoQD2qHqVTtpDioLCFB0Se8Y07cIjF9YehSS+1v8vcoFJSfmDXsLQ15bb04hAOVAdfevG1kda1JrRuXGsaLUwIzKJDTBJSt5A9S/kVHnA6Zr0ppt+YYKWobCtqQMmquTX1jc0ayMe0qOZbfEC4tSLC5lR27Tz0rydOn2ZeqERJzj5VIVkJbIG1PuSelb5q+TNctbseQytO5BxjnNeZtQSLg4p/TiGYVv82WmQLnITtWpKUhOzfjhIPqwO+aOIgrUkwOBk3dLHXEss6GLVDF2tD7kiF5nlL3D8h+vSpmS4ZmmdziufL3Z+Y5onbxbH/DdOl7OG5SjIT62kkBagBvcx2BI4oXZn4GwBgDB8vBHsSasK4chgNTLsTo4PeVFfqPWuWTIDbzzijwgd/YCnlEj7VWNQzjGsr4ScLd9A+/WrDnnUsYdBtcL7yiSXS/NdeJJK1lXPzNNUYFFUPed+BoaEFFzR0KEMMcmlZI47UkUsDNPEEA5FERxS8ccUkjjrS+UAkvp+4Bl4w3ThKjlBz0NX1lfoGecgHP2rJxlKgoHBHINXSwX5ElQjSDteAwPZVNTgzF8Wwi481B9ZsOknG5DyWF8pPBzVul6Bsd2jFl6I0oKPIxisost0XbrgHcnYea1G26ujuREOrdTzwe1Q27B2s5asCtuZYrHoyBFLcWEw2y2jqAOTVxt1wFrlmFIS2wgj07v1VSrXrOHHnkh0HjvTt31Zb5K2Q662QhW4BWDzVGzrY6Mv0WVqOoHmXpEL/GmlqdQNmTtNVS46MtEp8xJ8Nh9JPqCk09D8RrczHUFPtgY7Go1Wrost9yQH0hPuTxQr8wbj7XqbRB5j6rBaLVFLUOGyylI4CUgYrK9VyhucYBzz+9Wu8axY27G3eFHGc8Gsxu1xMma4snIzhP0q/jgg9RmdcwdtLI11wJjOqKgNqM/U1ml+uZnzfLQf4TfA+Z96ldSajLi1wYK/T0ccHf5CqoOeanZtmdT4R4eal82wcntFUMUB0oUBNqJoUKFCGGBzTg+tIHXmnM8U4QGEOB70XajHsaKjAI13xSkqUhYWgkKByCKI96LNRx/eaBp+8puMTY8cPN8KA7j3q9WYxFR1RpCyEq6Emsd0y75d+bb7OAp+/8AwVoCDIj4IyQeoo9JYcTjvFsRUt0nAPMkNR6c1FCjKuFjui3WxyWsZI+lZ7Jv2q1OlL8p5KhwRtxWhM36a0gBqQtsDt1paLyoLUpcSA8pfVSmxmoxscGR42V5Q6bKw34lItM/WFxkpjR3FLJP5lI6Vqlo05OiR25d9uy3SBnyDhKR9hUEm8LaX5jTcZkj+RNNv6gmS/StxSz0z0FEc9pFk3m7/SsKPl/ckb1JYXL8xLhDaPyis41RfnUKVBjLKVKGXFjqB7CrWG3Xl+Y8Sfl2rMLvIEq9SXk/lKyE/QcCn66RLvgmKrWFm51OLNGnrzSaUCCaaJ1sVRc0dCnxsTQo8cUWM0DDFDrSx05pA60s96cBzGmHRGjxjtRdzTtRCMkYJp2PGkSXA2wytxROAEjNXLStgZMNVxnR0Ob+G0LGQB74q1twwAlLSEtoGOEjFFKS3Mx8rxpKWNajZH4lQsuj32ZDcyfJDSkKC0ttnJz8zWhNQw8yHUpyCK4VRV/mx0rqYEhLOWnFoSOwOOasLWF4nMZ2ZZlEMzR5en0vIJ2KQcfp4rgVpWQMlt44B7prrD0/Yf8Aqn8Z/nNdDRkrTtdfdWPYqJpvlAymLrKxw04GdKvBJ8xxR7+lNdrVjS0jdg491d6e+HX2dUR/mNJMNxXUqOPenLQB2kbZLP3acj0dtplxtRGTxiqVcdExnUqXBcUwv+VXqSf3q/KhKUMKHSuR+ItnO1XB7U5qh6y3hZ70H9tu8x+4WS5W05lR1BHZxPKT96jxwa2hxseXsdQClYxgjIqoX/R6XCZNrQEL6qa7H6e30qu2Of8AjOpwvG0sPRcNH39JSO9HSnG1tOqbcSUrScEGk1EQVOjNwHcI9KlLRbvikuOLSSkcCuT4CUWkrDRKVdCOauNpiNx7elsjnrUVmzpfeUc3KFdfwnmf/9k=";
  const GUARDIAN_HAT_ICON = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHAAAABOCAYAAAD4kJKWAAAnt0lEQVR42u29eXhlV3nm+/vW3vvMR8ORSlJJpZJqdmHXYFfhqWxsY4ztjjEkN0AYEtIhkHSazgBJukPydPu5fbvvkzykoft2OvcGCBAGQxIcB+MGbGNGTxUb2zVPqkEqqTRPR2fae6+1+o+9zyDbdHLpa/nG8VePSqWjM653f9P7vWuV8P9T23zH27lz0zvIORmmF8cxNiDbnkb5LpVSiA0Nn/nLsvzih1Whg85sqehvT6ZSg0rpnpqpDvQUhg4jglXaWlPzV0oLwcrS3PKlidNHXSfUqtCm8wO9wZvecPvi2KFjyY/+9s+VRMQCdHZ0I45FsADx36Adn9DRGLEkgwSucbAJyBfyDF22k3/2u7/Lv77m1jVdJ3klQfr9f/sFers3sG59GydPnObEc8+T9NrYvH0vvT0Fdmzp4szxvHfi7JOZxeJ0xsvIkNTcNiE1LEpep00tGUhtj6fcLmtZp8S2YUIV6kACXdV+UMX3ywR+hXJ1ySpHqj19PZcc17XL5bK5OHE2qCxMP59Op3tK5YULfq1ctmAtVvt+5Ziytmqx2g+CFTDKV1W/Rs03WD/pJyZc42jrYTJtmcrYxfHFX37Pb+pP/dkn1nQN3bV4kX1vvA7HdLE4XmXrjv185Dd/nS1buhka9gD45X/5t+6m4Ta3o709o7W3MQx1x4mzp688dPjIurlLM1t9f2VTaPyMcmSDCW3KWusZtIhoUBAEPrVambBaxveraB3ghxVHax8/qGKswaK56uobc7/ymx/aFgSKv/7CvTz7+CP4wfIubIi1IdYarBWMWKwJjWAtWKyxxgIi2CRJCzZwUFOCGKvRqWS28r4P/dYjHYOb/xCYe9UAuHffWwnKJYLzGtmMY7CeNrq7VtNbg8BuGBuvdBWXylv+9Udu3egl3ZzV1+UXF5e3JZKZBDjZc8fn+fjHPsb4pRMoDGINxhi0MVgbghgMBmsNxoQgFkEhohAF1oRoozEISkG1ViLTnqZWNZw4eoharYQlBGvAxuHSmvqXAotEwDlYEKPqHy2JkEMJgqXQ3UNXoXdAfP2pVxWAxto+I/pNSLi5en75Cjd0s+2J3Nahwc71nV1eVjmeas+nwLEgoFSKnoF2LCAGaqUIJB0GGPERa7FYDIASRABjEAGlFIgFK0S/AEQhEuUyay3JZBrXcykVS/j+ChBg0URA1TOdbflabRaLiGCtRRCwFuUo+geGSKczplar2b9/Vf4RAZjBe1+V9H8MKSmsxRGH7s4u2ttSuK4glmgRrCBEC2M0EQACg1vbuf4N1zP5lfOEocaisfXFtQCCIw7GaqwolAgm9iaLgDgggmBIJNNcfe3NZLIZ5qeX8P1SdJVYILokmkBZu+rf1oKIIPLikiGZStO9vh8c5kKpFNcaQPW//hQ/3rxUtpRJdoD1EDxSyQ42b9qGl4heNgwtfg1Ky4bTxxeolKIFFWURsWSyHj/9zjtYv2FjFOFEYm+TxoKKRL4jEmGhGgttG0BYa1i3rpcDt1yP4wrKEZTjEF0Czb+JHtUCHtH7+TGfz1pLti1Pe6ETEXV0vrw0s9YAvqwe2JYcfDbd3lZKpcbzlcoKWzZdwTXXXYXjCNqHC6eLnDk5w/LyMo888k1+7cPvZu+1G6NFc8AaS9+GNjZu2c7ExDmMrmB0tMBKwEYZsBEyhRjkePEtBlEufb1DbN6xGzedRCnIZNO0tXcgVsUBOULJGoNQD7kxnHWvs63RsQ6pJdOWJ5HJYK3YtjCx1vi9zFWozlzauePa6aFtPfn5hWW2bRtk644uXAcunFnkb//yOxw6fJgwLDF68QSHn72KK/ZtxFGgIgchn0/ywX/1bvL5JN984GvRQorFqigfYojzUnNpLRasQSmHZKaTd/zCB7n1rpto68gggJfwSCbSiFUt7mWBVgCjC8NK/Ls43DfDaHT/bK4N10sTaovYte/KXlYAT166NHGgLTVyzdVbtrR3eLgJSCSjUv3UyXN84+GvUKksgBishScff4rbf+YNrOtPRWAoi6Ng995+kh98O47jcvr4CUZHz+IHFUAT+FWiHKbjsKgQiUC6+robWL9hE3uv3kXPQBuYKMd6nkcmk4mKESUICmv1j/0cYl+qpIlKn0w+F+fhcMLRoWGN7WUFcGTlkUCrd89YE5LJe9FHFqhVLMeOnqFWW4mqQGsQ4PzIGc4eHaenZyvWie4b5TbL9sv6+L17PsjY6BxPHzzC+ZGLJFMey8tFFhfnePbZp+kq9NDR0UlXdxf7DlzFDTfto609jzjE3gO1wLAws8jSwiyIaVS2lqiAjR3tRYkvcrwX3xhXpVahnualcf7HC6C9dMKoauZgaUW/B2uxVigtWy6cXWZ8bDLygDj8CcLS4gxf+PRX6Cz8Ipe/vh8rEndi4Ajk8g7bL+9heNstBL5BRYmQmellThwfZ936brrXZUkkPXJtScSx2DjFGSxWCUuLK3zuk5/lzKkjKAXG2mbjUC9+hMbrxiVoDE2z1agXOwbBWIuxof3Ef/yjtcbvZWdi7MpycG5+VldLRUktzgUce+4ijz/1OKdHjkYNc2NdDKJ8nnv+hzz6rS1ctvvncNIvuKDjRJdMQCquZAXIbOpgYLiDIIwrWBVdFKGOcmk9OlojLM0Vef6ZJ6hUF2k4lY1bh3r7KFGP19pOCC92L2tBjMUSUpVSuLbQRfayU2mVavHk+ZHFhaW5lfXHjx3l6R/9gJmFk1T9hdgDoytf24hpEQk5cfwMi3NV1g2mVq1afREl/qqX+CKRP2gn+q3CYiQuhOphUVswlnxbjvX9vVy8YEHZhmdFz2Ebz70qmb0QuZZIao0hDGuVqfDimjIwdXvZAaxJdfrMmeNnT518Yv38/HkqwSKaChAiohqroevMhrUcO3aMB+9/kre+43oK6xIRuQKNnq+xhi0LKRgcIW4rQKygBEIiMKJQB5m2LHv2X8fzz3wfPyg1KxQhYmNsveKMwnoTqRd/NhHBdRMsLSwEJyeP1l4B/F7eRh6gvGiWq9W50WL5EuXaNMbU4su7hfICHOUQUY6GcnmOz336k/xff3QvF84uNj0uLvGbmfGFZmNAbMNN60AbK4gDjmvIt+dJpDINluWFT9FoSVrfoqy+T/R7AULOHjpSnH78/Jo38QDOy/0Cd735f7crxYv7isszN5bKs3Umk0a3TXTlO46KFhSDxVCtFTlz+gyT41U2b9pM17pMIxxGj6lDuto5mkFQVhUa9b7OcV02DG1kZnqOM8cOR81+nQutc5w0a5fG874AaRHBcT3SmTzj584tFOfnPlsqVhbWGL+X3wP/w3/eivXcU47nxVymxkrYwv5H9zNaR8SzxPwjllAX+eH3HuKz/8/XmBgtxgRyHajm94gWlcbiR51d9OGEiLVxlICxiLFkclmuueFGkskox0o9RLe4mbyoY4jvIc14oESYmRinVFz0HVeV1ho8WAMAAVTSGRHXics+HTfNUX3fAMxaTDR1WxWtQr3Md7/zIPf/1XepVvTf+1p1GJWAioZL8W/ifk9Aa7g0MUnNr0Ve/YKKE1aT180wausceuPCK5eXsTpY9AyvzhwIkEsXJh0nUQT1Y4Y0YOKGXSwoUdQBBku1tsAj33yYs6dn6w8BXjhDaFaoSDMBSvwh64BoDX5gKK9UsFqDMRGAEr/iSyTXel3T+kpKBGMMoR9gDWdNYFbWYi1faGsCYHfH+tmkm7qE+p+/nIjE+chQD1fRcFUzMXGObz/8NLVaa56ySCMUtyyxrWdSMNISc62iUtR8+4FvcfB7j6AkakEaM4jWPvBFFhHbdbZGXIVynChyKFP1c8Ga02iwRgDu2b2z7HrOmJJm11JfthfN3rDRTK9eeMRNQC2oMDk5i9a2sYj152k+X9OiR9kWLxWWFio89MC3+Nyf/jHHDx+Mnr+FBG/9/lIm2Ab11lYo0N7VCVgCL1yePrP86gXwjW/Hr9mVH4oo05jOYOJFbgRRiMdDDUoLYn80OJ7DZbuGSKRb5nhSD73NUGkBTbP3szbyZ79qePSBb/P5//uPmZ06CxLfq+51EA+YX6rirOfU6A7KQjabJ5vNYTHGWn0mkhW8SgFMgs0mukY9NxWudh3bQiCv9ilb9yGxRBMGh3Q2gVLN+9uIXIn4zGZxiLZgTEtPbuHYsyf42y9/kempCxgbxtVwvY3hfzq4hRaVRvxzqVjEaAM44lg3+eKMvDa2JgCKCI6XPuR4qTFkNavYumjS6OFicV+DEpEGPwlRaNQ0PU1j0U2VRUuHGJkO4enHnuD86WMoVa9UpfmA5oMab6oe4hsTkVX+JVRKZSqVCjZK3EMvXf68/LYmAAIkO/PziVRuicbiNkWzUfhr/okKGAVWEByURKFwfm6FMGZKTMPjBGMFIxDaqASqSy4gum+torl4cZRQV+P1l0jBJqvfjWkJya2Ea93brW12i4Ffpbi0hAIc4ySG/7fNrwR+a6MLBdBtRjuJhJaXbCWa3Z+IRKGtISSKwmV7e4Ft27Y0YY/VZyvLIRfOzJJIuIgkSWQM3X05EhmnEZaTCYeBgQFEvdA3m23HqiI2vjBUS1iPeNvmY+qjsEgZJ9naY0suEKzVetZtzQDMJFLWcz1L7Fn1OBX5zOroY00MoIopMWsolYo89dhhNl82SE9vEq1hYb7Ct+5/nAe/+nWUA5lUDqMCrn3DtbztF24nU0hFNJ0rZPNZlHLQNmwQ1c35w2qT+oyrwXNHMz8Q6jgqURTWdTM/M0lYq4nSLzsr+QoDmM3bRCJrsQ7Y5ixv9fdoUVXL7ZHQCFaWZrj/r75E0vN44503sLxQ5KGvP8S3H36Q5eIk1ppIJWh9zp15nq7eLm79mQN4CUFby9xiEesmIQiwdRkjKs6ziiijrpbItFJ3jZtjCZxyXPqHNlEtl1iq1vrwTIpXswcO5Lbq8+4RrZTCmGZV0AiTraDF/2j0aRJd8aXlab702U9z8IcHKRbnmbh0Gj9cBgmixXaibLZUnOH+e7/Kzqt2MLyjB6Xg9rf+FFbgga/8Bcvzl2IFt2mAUr946sG8XkK5qRRKCX65gkVIZFJYUWTaOlm3YZCL584iIoOkVBuw5rrQNQOwxxm2aTdn67lEXjSnaanjDS92z9gt/XCeYye+hzE6inUSLXpdYQ0OVoSxyVFGRsbYuL0HBLZdPkhX789z5vRxHn/0QbBBg+yWui7b2AaMEXEj7Lr+Wjo6OvjBtx5i047trOvvZ/rSDEPbt5MvdBEEASCuaLX2mkLWEEDXcfC8DEqplrJcNa58g42oLRsLdRsoNoRDiJh4omEQp6lAqnuvqSMuDgMbB9mwcX0ER8yz5jvTvOv9/5yVyjLj506wNDtDOpVCOS5LC9OxqjtK0U4yQfdAPzfe+VOkUmmSuTZed+VevESKsbPn6V7fR3FhAW0sBjx8nXxVA7jUXhRJ1+d0LbZq5tZ6U0uNH+9JMNQ3ocReF88PI292kdgLHdfj2htvYPP29Q3GRmwksdh37R66+v4PJsfH+c7D36S/fz2pZIqvfunPGRs5hQ1Csu159t/0BvZd/wa27tyFMbBh4xaMNdSqFTwvhbaGoOqTzmZZmjOi1dq1ZK8IgEe7HifI1UQpt4HLC3rnRs4T5RCNnSLPbEzYqbcXCmvqcsA6ma3ixlvRUehl0/bNuF60L8Ii8cxPcF3YtGWAgeEBtl5+BZ7joXVAZ283D3/9qyzNT7P36qu56oabaO/sxepozOVXfMLQR0SRSCYJ/YBMOkNHZyeXxmyhmq5uAI69agFcMiXtSHJROR4m3gZW5x1bNZd1nOqeauM8F+0yilp+CyRSGTJtbYgCL+ESBAHl4iKVapUdu/ayd9/OF7codbmEtbgK2nIZdGjRjuLKq29gaMc2KuUlEokEjpvBajA6jLe0hSzOzTI6MsKGoY0oJbiuS1thHVZUUmyiANW1xm/tALxt113+U/d945zrvnS/1NCfGGkMWAVwWybgqCSFng0Mbh5i91W72Xv1lShHkUy4hFpzcWyC0Qvn2X/t1XR2pRusXZ0PNabZ2yESb6KJmSDlkPAyqKwbb22rsrywRFs+jw1D5iameODLX2L8whl+5n3vo3fjRpTj0NHZieckRAJSa47eWgL4c+cSPCPJmpJEnCxag6g0C/io+Yu7s1jUqzw6unvYvmsPP/3Ou9m2Y5iO7gzJVJPVscCe/Zsw5kALDUaTWm0gGd9s4iI2ljUqXEaOnESsZnjTFv7u0e/x5A9+wC2334FfrfK9h77JieefwdgqszNT9G7ciNGWankF0QbXkHtVAxh2Y5Vya464zaBW5ysbK13/ORIaEXOg2bY+fvXXf4NrbrmC3t4cjtSJbLuq8HGI2Jv6XKDuxc2Xk0Y6tfVZVvxoUS5iLI/87d+wectmHn7w64ydO8f0xQsIlvHRc9E2bNHMTE1ijKW0XGTs/Fl0GOKIcMWV2zjy7OlXJ4DeTuH3P/RoEG1AWS0Oam0FYgQRFZPaVuEk0mzbOcxAXy4aqNY3BNKU1TU80UTtiGm5veF4DQW2xCE1GkfVnTPflufE88/y1HceolpbQduQidHT0Rbu2GWNtcxNTeNXA+amppiZuBQ9n2KHvHDU8moCECCRTJHw0g2Pq4t1V4VSsVhxiPeNgQjdPb1kc6nG2LfuV62CpbopqZNi0cNNS+dhDfEO4KYiTke6C9CG0ZEzLC/NUC4vUd9qFuXLli3YAtZoqqUVLp47R6VYij6Hkj7jaIdIS7xmtqa9S1u+0+nrG8J1sijxYqV1BIeqE9wiiHIaU3knkeKOt9zKxuH2eEArzclbiyRQxYvb+mVt80uI8p4JQYeCNjRqVBFhdnyCRx74GuVSMb5uVCxOXHW5IeLQUehicW6a08cOY7SOLwaTnF9cXFOHgDX2QMcz6prrbqJ/cAMjI8c4deopdOhHv2yMjpqaX+Uk2blrH9fcsAvXFVokLA2Teou4ine2YBVhQJ1do0GxINHtbiRociWS3D9/8ClOHz7UVAq8UFoRh/lkOkX/8EYWFuaYn56gHqyttV5Q89e8mV9TAI0tq9dfcznX37yL0yf385k/X2b0wuG4z4v3v1uwxiGZynHTm27nPf/8bWzesq4xf6sLDlugirzV1r0LKlXD9OQyiwtlVlZWKHTn6d/Uy9JChQvnxsl1dNC3sUAqrQitASV4SS+ScUhc4LyUWUMym6Krdx2zk3PoMIg1roIg61yVaAPKr1oAdViV9k5FvsulsG6IZ57ezYXzx0BZlKhI7qASaOOy/5pr+LWPvJcNg7lVeyFaM2bd64Ka4dDToxx5doRSscLc3BwnTx5lpbhAuVykp2+Qm950O2dOHuOZZ75HvrOTO9/yFm59y214bRmMWPZddz2bd+7kyDOPNbjXVdjFfzzPI5VOs3FoM50965kaHcERhVi1S0J5Y3df7kuzk2snEV0zALdf9QEcxzFKCY5jUWmht68Hx8lgKAOKXLbAgZtvpWPdOg7cuJv+DblY7NvYPvQCTVR0++mjl/g/7/kEYxdOYUxIqGtoXWsozyanRjh+9EmCsIo2VS6OaSbOneTsyVPc/d530b9lAMdJkEhmWy8P6qGUlqq2Vq1SK1fp7x9g11VXMzN+IepbrU1g7J2JXOqrsLJmKu01A3B6aSHRtb59KJVUYCLpYKFrgK7urcwvnqU908ltd97Bez9wJ7n2FI6yqLgQxQr18wia7GfU7+kQHv7mI5w98wzWVqlrWOo5VQS08an51UYlo8RSXJnla3/zOU6eOMwHPvzbbNq+lWQqj7FuLPYNMatouKhUqiyVGDlxiv6BLWzZsZO/+0GB0vJivDXOHBDfDAGn1mpd1yzp3vq6GwrdhdzuRFJhLZSLUCsnaMt1cf31d/HBD/0GP/3u2ymsS5FKQSIhEWHdOoCg2S/WQ1xxvsbxQ6fQOjrswFqNtQZsCFZj4j5CWnrO+hMGpsqxQ0/wtS9+nkrZ523v/iWGt+9qqYYkUmNbaXC0Ogg58szTLBYXIlWasSQSCTLZLIjaYKy6buuetRM4rRmA27bsvKyzs30YFKUlyzcfeIZvP/oQxfIkb77jBt581+sYGMw0lWLWorVF66a+0xgagGpjWVkI+db9Bzl26BDNypHGeWfaaIzRDcU31mKNaSjCxUQzxse/9y3u+9KX2LT1Cn7xQx9lYPNORJy4lSAO3U3p4cyli1waO4+xBt8PqFZrdHR00t5Z8JKJzJv8WmXNhrtrAuCvvucEhb7cvnw2la6UDN995BBf/uKfceTwQ2i7Qv+GDIlEc5+C0dEOIoxgQzAB6ABqPvi+JfDBBsL42Xn+8t57WVyewqAbUvrGoMk2PdLaSLJv4nxmrEUR7UmsVJd54vtfZ25qij1XXs/Nb34b4qRadhDX959FMbm0tMyx535EIuXheC5aG4qlIuuHhxnecdnVG4a29/6ka7Xxpu1c+7O38Wt/+C8A2L73cvoG17N+fQ/969fRNdxOao9H8kqH5H5nbXLgoeOf9w7c+PP70glP/ejvzvCFL3yG+cUxrAnp7uohn89HJzBJnGp0RHHV5e6W6LbQgNZRH6drmuKiz/LyHJoAsQZwmicsxWGyVfFtaaXsmvJ9FMxMXWLy0gTdfRu58uo3MHL6OOIEjBw/xtTYufhAhvqbUihHkUglSCaSrAgUl5aYnhhn/eYtm3Oprju2H7j6k6ceO7ganFs2klnOUi5XSHW1sVis8cGP/juGNw2S9B0IQp589BGef+ogg73X8Sdfu4MnH32Yr//n/8qBbUnOq50c2fmcME4SQeFg1gTA4S3buzs7Oq6cmlniy1/+CpMzp1Gicd0Uu3dfSS6XQQexNkVbWjv2elOvbXTqxPiFIo88+BRTExOUivMsL83E4iTb8LQ6YA3xsH3Bk8W/N6Ypt8BC6AcYa1m/YQe/8KsfJbAVTh/+Eff9xZ8wMXoKbQIwhnyhnYFNQ6QyGTq6CizMTGKMYXZykiDUbq7QdafKZj+/eevWqnE0xg+w1lA9X6G4vER1qcz6XMoLazXPr/ou0AckgbTv1zY5nrtBKRUAZm5qKp8c6O3+0YpVwoRdf3CdG3j+ZSjSVnhuTQDcuKXrsnQ2teG73/0+x08+AzbA4rJn77XcdtstUXHggw1tdMCgijhLo6OoFQIYKK+E/NUX/oYHH/hLwrAMYghNscXbWmnIJnjWmgbN3OA068QMUX6r1XzmpmbQPoShkEy2oYzHtsv287Pv/RBf/tzHmbp0HsTSv3kLvRuGcJMpdlyxh/GREYKwitWW5blZKqWV65PJ5D5R6lmEgojkLZLDZWcql+5IJtPrShfn97TnC5lMRZI5yW4xBKnQaIWVzNzUlLcwPUWusw3HScSjr6iydqzgBCli3li97AC++df+moHOjXtWitXcEwe/jzbLgKWraxO333k3XV2d1EoWmyCivBQgBqMl8korkZQU4eyZSX742MPUgvg8AWObWa9RqtZHTPUNoi1gQsuRWvVtTRFR7XkJ8vkChKBMpFAMfItYh8HNO7n1rndy4fxJRCzrB4dwaWNlvkpnoZ/BrTsJg4D2tjampkepFEu9EspnatXyiBW7DaOzWBJOoAqRRMMAir7+DXR3dRCWq1RWSlRWSuTa2th6+esoV1aYGr2Aqfk4ysFogwKSySQo8YPA/55V8kfugZvfSWVpmVk9i+/4pHMKMYKjhcSiB2EiquSkiqtc9u9/O1fsfCOdnUNorZhemOLZ8/dzaOIR5qcnUbpMV6WAg0vNwMkn/jr9luE/eNPyQpnpuUm0rZFJd3PbbT/L9u07WVkCVwnLWpMvOKAsxqhocuBD6BvEFRxPuDh6ibmFi4S61pDcU9+AgtMc3CuJgbKIUtGhdg3MTHMuKLGgVyna2vs4P3KWSqlGtVYhDH1C7RMaH891SCc62bv7Rto7smRzOdxkknQ2Sb4tzVvf806S6RTVUpn/9rF/zzPf/wFh6G9T1m4zuuWUU6PIdxbYsGkTA0Mb7aYdO8XxhKX5Gaq1GtYP6e3rxUsoRo4d4bEHTzI/NY3VQVydW/zQP2XE/KdA1f4qEWbmXevohCZIlJ1yUE2VbYKMo8QVJYpQ17yJC+MqlUnRtS6Htdr4QU2JUl2ZdM6G2rHJUrGEK0unx49Y5icNRcxdb/l97eazdOY6ePbMk72up/YUugoMD1zGGLDnqlu48eab8H3D0cMj+LUK1VKN3Xs3k8qkWF6uEdQ0gW8YHR0jlU3SWehi6mKF4aE9iIQggud5KMB1naj3E4s1FqMNNb8csTKhTxiG8f572zjdVxwXUfFzuC5eMks27dK/3iOXzZHOpEhnMqQyKTLZFLlchkTSI5lJ4CY9tGqOrXwLVV9TLZW54+63MDV2ltFTZ9FaR/sVjUYcj01bd3LDHXcyvH0byVRCfN+nXC4Rao0f+CxOTTJy5Agjx48yNzmBNTra7iOCESYR8ykj9gvBoj5Jp6DSFrn95l//RLW8dNX0wkjVKm0FceNDyvAkldx9+TXO4tIy50efQ2xgXC+n1vdf0Tc0eBXr+19nHC+5tLAyNnf+4jNmbOKQqZVWZhM6c0p5CTwvazs7Bwf373nD+3p7uhMTE7MsLC3S07eBVMZhcXGes+fOoH0fsZp0OolyoFQpE4YhgsKYakxVaUJTRusAY6MPbLQhNJpQ1wiC6CxRa6Khn7EabXyMCVo2rhgQg4hCOW7jdGYrip17X8/v/MFvs2t7b0Pw2zq0DyNfRRtDsVRidmGBielpJs6fZ+L8BS6cHWHm0gQLs9NMjY9RLVWiWkyETL6dvdcd4Jqb30ihp4vAr7JSKkWiYIHqygrnjh/j0FMHmZ+aBKMRFZ2CYYWKFXu/74R/6nf5j+WmMkYSiotnp6OgcvuNH35isH/o2rPnfsTU7HksGmUBleDWN7+Nd7zj7Xz2U1/miSf/O4qoStMY0uk87R39dHYOkk7nwYSUK0vk2jrY8bohcm0JEl4yOpdTXEQgl+1AOS5aB2jjE5oA0CQSCmNCAt+PXt8Bx3W4NF7iu498l6nJ0WjsJJog8OPHhzFlFo95xZJM5dl2+S4uu3wzKyuLnDszwuzUJCvLS/i1GsYYDBqsjqYfysFLeQxv28FPv/vnef3+3YS1CivFIotLi1QqFZaLy1RKZRYW5lmYm2Nhbo656UkmLl5keXGRcqlE4PtR32N1NJdQCsTB8Tz6hzdz1YEb2b7rctyESxgGVCo1KtUKQaXC3NQkZw4f5uLpM/jVqDADEJFQFAdR8qdBxt6ny7rsODB5dmFVjeHWTPVPk/mOcP/1d18T1Ere/MIlpiZHWFpZYOvO7cwtLXBu9BjaVJsbKAVqtRWmp04zO30ex0milIdy0tz8prv4pX/xs3R3y4tYAvkxP7/UzkgDPHt0lrGJcVZqsyzOFalVSg01kiiDNRqJ/6sAL5Hk2htv5U1338Xw9i5qQYWL58a4cHqE08ePcHF8HNdz6envI5lySSYSKFFoE7C0sMD9936ST31immq5gh/4VMtFWytXV3QYIkqllBLPGIMOw5YdvdFieEpFUgDxUCI4nkd7dx+X7b2SbVdcQa6tDb9Wo1hcplqpUCoXWVlcYPLceUZPnKC0tIhFcJRoERWCncDKn1iPz8sy05KEmQsLvJTJrTd9mHJQ6do2vOenBgYH39dZ6LrO4KfPjjzL0ed/QK02z0pxHqPDZt0tqrFrVokTl48OSqXYf82beccv3k3vei8+BaJZBRpjqPnVRl/WugmzWvGjwsJxUI4LSijXLKNnJzh17BjPHfwhUxOjWBsSak2oQ6zVKCxKCZ6XoLtnkFxnB8oRI44KE0mPbK6Njo4OCt3dpHOZsm+Cc54rVqzFc1wwhrmpydL3v/3wYwsL8zVxkrQXuhD0xOljR36kxLG9/QOb2jrarlACc/NzhFWfcqmE7/tYKyilyGSz6d4NAwfSmUy6rb2DQu/A6ODWrYeUKxIGoQmCgEqlrCrlkho7c6J/YmTkwMrS0gphSCKRQJRbLq0Uv2h0bcy69mxp+MoT2fPPW+fGNs79xciPrfLlpqt/Gbetg53D1/Ls9Dc6tvbvuzpf6Hh71vXeNjV2ovvwc4+yuHARE/ixwrmuTImbNJymWxpw3QzpXKZxUqDUz+MUBxEHvxYdruN5brT12vFwnQTRqbnhvHKduUJXD/2DG/BSKUyg8dwkJvARZXBdhzAMuDh+4djk9PhYLpOno6OT7q5uenv6yXZ0MHFp/KmFublL3et66Fm3jt6+Pjo7C/i+X/zaww+eVFbbfDbN9m2XccUVOxncMKi3DQ6WNm0dwqBwE0mM8SkXVxAiJXYqlQQstVoVG0aeGBHl0YU8cWmKe/7LJ3I6DFWlVmNueam2ddPOmpd0qVTKhGFAGATUagFf/eQfJ3dcvqdvYWZ+wXEcOju76OjoNL/0Hz5efuvGHtM11IXBZfzC1N/bpjWi184DP8W2TXtZn9vGY6fvc3fs3LOvQ2XfX6vNvm1p9tK62clR5mYn8cslrNWxZD2StIuoaEMI4LgKA0uu67ph4GeNMXR2bKo4TvYPSpXiaCaVxfE8+tb3kXA88vlOurr6yCSTVCqLY1/96pfOd/f2ceNNt9DR1U0ykWbrph0kvQSF7i4KhQJKLFt3tC8pT6o2BMeFbDaHkiT5zgJX7ns93d3r6Ows0FUo0NPXR3dXN1prvvPUDxA06USCDQMb2Di4gXQyCcZw+y23/L0L9uPsAx/5LcCilCLQhpo2bO8oyJ9Vn7Ljf/gNfuELlsqh34LyPFt7+uW55w7bybFxxFry+TYy2RyF3ZerBIGEvmc+/7GP/YPUbY1G/vhjD3L8sQcBeNf7/yi0jv/UfbP/7Zmb8rd92l2n3j/QPnx350AhPzsxEc5PTxHWapJ0c24u17dS80tHRfFszS+d6FnfjXLUMc910/MzU1vKlYodHN6Zev/7/vBzH/23dy/WE4gxBivRxCAMAwIl+H4NL5nEdT20MfhhtBlzubiMqxRWNKH2EWuYnpmkTrzoEJaXVoAVFhfnGDu3ttpMgE/+8cdX/XzPPfeIBT6Qvkbu4Rv2L97bzPTv+qV32Y6ONr5x34OrHnPz4D6zMfv/7rCEl2Ri7v307wJwzW/cHdqqfepU2+PPbF+8/s+8fFvbhq3ZRVEiy3MLXn/vrs4rdr55VFz33Mc/8f7KxsF+G/h5rAjG8wj84GGjNVOT55mbneTo0Sf/Ye9qBB5/6qE1B+H/Y/uxHnTvn9/7krcPZqvYuubxH2j/ILT/2a++jXTQRhiGuFgunj3Dk98/KAC//ZufsspVLC6fZv/+W/mVX7kNgN/5nd8hDEPm5nLE/8cGn/nMv3+lF/VVZz/x2SYf+eRXXC9MmvZF1/ze7931Sn+Of7L2E5PZQbKq33LfO+zN33hFzrd5zV6z1+w1e81es9fsNXvN/snZPffcwz333PNKv43XjJ9cF7pqj8lr9o/M/s3v/it54e6d1+yVsZ/IA7fv/nk+88WDr8jJRK/ZavuJmBhf1wRI8EqcbPOa/a+btZb7vn6O//rlx17pt/JP3n6iY2aPidDV1pMCzH//6z9/LRm+gvY/AFKLW571tf5FAAAAAElFTkSuQmCC";

  const FALLBACK_GUARDIAN_SVG =
    "data:image/svg+xml;utf8," +
    encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120">
        <defs>
          <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#0f172a"/>
            <stop offset="100%" stop-color="#1e293b"/>
          </linearGradient>
        </defs>
        <rect width="120" height="120" rx="60" fill="url(#bg)"/>
        <circle cx="60" cy="74" r="24" fill="#cbd5e1"/>
        <circle cx="52" cy="70" r="3.5" fill="#0f172a"/>
        <circle cx="68" cy="70" r="3.5" fill="#0f172a"/>
        <path d="M53 81 Q60 86 67 81" stroke="#0f172a" stroke-width="2.5" fill="none" stroke-linecap="round"/>
        <ellipse cx="60" cy="52" rx="34" ry="7" fill="#ffffff" stroke="#0f172a" stroke-width="2.5"/>
        <rect x="38" y="18" width="44" height="33" rx="6" fill="#ffffff" stroke="#0f172a" stroke-width="2.5"/>
        <path d="M41 25 C48 22, 54 31, 47 36 C41 39, 39 31, 41 25 Z" fill="#0f172a"/>
        <path d="M66 20 C75 21, 79 30, 72 34 C66 37, 61 28, 66 20 Z" fill="#0f172a"/>
        <path d="M55 37 C63 35, 68 43, 60 47 C54 48, 50 42, 55 37 Z" fill="#0f172a"/>
        <rect x="38" y="42" width="44" height="7" fill="#38bdf8"/>
      </svg>`
    );

  function getGuardianAvatarSrc() {
    if (
      typeof GUARDIAN_AVATAR === "string" &&
      GUARDIAN_AVATAR.trim() !== "" &&
      GUARDIAN_AVATAR !== "СЮДА_ВСТАВИТЬ_BASE64"
    ) {
      return GUARDIAN_AVATAR;
    }
    return FALLBACK_GUARDIAN_SVG;
  }

  const STORAGE_KEY_SETTINGS = "gg_settings_v1";
  const STORAGE_KEY_DM_LOG = "gg_deleted_dm_log_v1";
  const STORAGE_KEY_SCRIPTS = "gg_margycode_scripts_v1";
  const STORAGE_KEY_BEST_SCORE = "gg_blockblast_best_v1";

  const THEMES = {
    "neon-cyan": {
      name: "Неоново-голубой",
      accent: "#00E5FF",
      accentSoft: "rgba(0, 229, 255, 0.18)",
      accentText: "#031B24",
      panelBg: "rgba(10, 22, 34, 0.78)",
      panelBorder: "rgba(0, 229, 255, 0.32)",
      pageTint: "#061018",
      textMain: "#F0F9FF",
      textMuted: "#94B8C9",
    },
    "pastel-pink": {
      name: "Пастельный розовый",
      accent: "#FF8FAB",
      accentSoft: "rgba(255, 143, 171, 0.2)",
      accentText: "#2A0A14",
      panelBg: "rgba(33, 17, 25, 0.8)",
      panelBorder: "rgba(255, 143, 171, 0.36)",
      pageTint: "#160B11",
      textMain: "#FFF1F5",
      textMuted: "#DFB0BE",
    },
    emerald: {
      name: "Изумрудный",
      accent: "#10B981",
      accentSoft: "rgba(16, 185, 129, 0.2)",
      accentText: "#022217",
      panelBg: "rgba(9, 26, 20, 0.8)",
      panelBorder: "rgba(16, 185, 129, 0.34)",
      pageTint: "#05140E",
      textMain: "#ECFDF5",
      textMuted: "#94C9B5",
    },
    amoled: {
      name: "Темный AMOLED",
      accent: "#E2E8F0",
      accentSoft: "rgba(226, 232, 240, 0.16)",
      accentText: "#000000",
      panelBg: "rgba(0, 0, 0, 0.86)",
      panelBorder: "rgba(255, 255, 255, 0.2)",
      pageTint: "#000000",
      textMain: "#FFFFFF",
      textMuted: "#9CA3AF",
    },
  };

  const DEFAULT_SETTINGS = {
    theme: "neon-cyan",
    liquidGlass: true,
    avatarFrames: true,
    miniPet: true,
    hideAds: true,
    downloadButtons: true,
    dmLogger: true,
    museReplacer: true,
  };

  function loadSettings() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
      return raw ? { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } : { ...DEFAULT_SETTINGS };
    } catch (_) {
      return { ...DEFAULT_SETTINGS };
    }
  }

  function saveSettings(next) {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(next));
    } catch (_) {}
  }

  function loadDmLogs() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_DM_LOG);
      return raw ? JSON.parse(raw) : [];
    } catch (_) {
      return [];
    }
  }

  function saveDmLogs(logs) {
    try {
      localStorage.setItem(STORAGE_KEY_DM_LOG, JSON.stringify(logs.slice(0, 120)));
    } catch (_) {}
  }

  function loadScripts() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_SCRIPTS);
      return raw ? JSON.parse(raw) : [];
    } catch (_) {
      return [];
    }
  }

  function saveScripts(scripts) {
    try {
      localStorage.setItem(STORAGE_KEY_SCRIPTS, JSON.stringify(scripts));
    } catch (_) {}
  }

  let settings = loadSettings();

  if (window.__guardiangramLoaded) {
    if (typeof window.__guardiangramRefresh === "function") {
      window.__guardiangramRefresh();
    }
    return;
  }
  window.__guardiangramLoaded = true;

  function cowHatSvg(size = 28) {
    return `<img src="${GUARDIAN_HAT_ICON}" width="${size}" height="${size}" alt="Guardiangram Hat" style="width:${size}px;height:${size}px;object-fit:contain;display:block;pointer-events:none;filter:drop-shadow(0 2px 6px rgba(0,0,0,0.45));" />`;
  }

  function applyThemeAndStyles() {
    const theme = THEMES[settings.theme] || THEMES["neon-cyan"];
    let styleEl = document.getElementById("gg-dynamic-style");
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "gg-dynamic-style";
      document.head.appendChild(styleEl);
    }

    const glassRules = settings.liquidGlass
      ? `
        header,
        nav,
        [role="tablist"],
        [role="dialog"],
        [data-gg-glass-surface="true"] {
          background: ${theme.panelBg} !important;
          backdrop-filter: blur(16px) saturate(160%) !important;
          -webkit-backdrop-filter: blur(16px) saturate(160%) !important;
          border-color: ${theme.panelBorder} !important;
        }
      `
      : "";

    const avatarRules = settings.avatarFrames
      ? `
        img[alt*="фото профиля" i],
        img[alt*="profile picture" i],
        img[data-gg-avatar="true"],
        article header img,
        [role="button"] img[draggable="false"] {
          box-shadow: 0 0 0 2.5px ${theme.accent}, 0 0 12px ${theme.accentSoft} !important;
          border-radius: 9999px !important;
        }
      `
      : "";

    const amoledRules =
      settings.theme === "amoled"
        ? `
        html, body, main, section {
          background-color: #000000 !important;
        }
      `
        : "";

    styleEl.textContent = `
      :root {
        --gg-accent: ${theme.accent};
        --gg-accent-soft: ${theme.accentSoft};
        --gg-accent-text: ${theme.accentText};
        --gg-panel-bg: ${theme.panelBg};
        --gg-panel-border: ${theme.panelBorder};
        --gg-text-main: ${theme.textMain};
        --gg-text-muted: ${theme.textMuted};
      }

      ${amoledRules}
      ${glassRules}
      ${avatarRules}

      #gg-fab {
        position: fixed;
        top: 14px;
        right: 14px;
        z-index: 2147483646;
        width: 48px;
        height: 48px;
        border-radius: 18px;
        border: 1px solid ${theme.panelBorder};
        background: ${theme.panelBg};
        backdrop-filter: blur(16px) saturate(180%);
        -webkit-backdrop-filter: blur(16px) saturate(180%);
        box-shadow: 0 10px 28px rgba(0, 0, 0, 0.35), 0 0 0 1px rgba(255,255,255,0.08) inset;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: transform 0.18s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.18s ease;
        padding: 0;
        user-select: none;
        -webkit-tap-highlight-color: transparent;
      }
      #gg-fab:active {
        transform: scale(0.92);
      }

      #gg-modal-backdrop {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        background: rgba(0, 0, 0, 0.48);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        display: none;
        align-items: flex-end;
        justify-content: center;
        padding: 12px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }
      #gg-modal-backdrop.gg-open {
        display: flex;
      }

      #gg-modal-sheet {
        width: 100%;
        max-width: 440px;
        max-height: 86vh;
        overflow-y: auto;
        border-radius: 28px;
        background: ${theme.panelBg};
        backdrop-filter: blur(16px) saturate(180%);
        -webkit-backdrop-filter: blur(16px) saturate(180%);
        border: 1px solid ${theme.panelBorder};
        box-shadow: 0 24px 60px rgba(0, 0, 0, 0.55);
        color: ${theme.textMain};
        padding: 18px;
        box-sizing: border-box;
      }

      .gg-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 14px;
        border-radius: 18px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.08);
        margin-bottom: 8px;
      }

      .gg-switch {
        position: relative;
        width: 48px;
        height: 28px;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.16);
        border: none;
        cursor: pointer;
        flex-shrink: 0;
        transition: background 0.2s ease;
        padding: 0;
      }
      .gg-switch[data-on="true"] {
        background: ${theme.accent};
      }
      .gg-switch::after {
        content: "";
        position: absolute;
        top: 4px;
        left: 4px;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #ffffff;
        transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1);
      }
      .gg-switch[data-on="true"]::after {
        transform: translateX(20px);
        background: ${theme.accentText};
      }

      .gg-tabs {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 6px;
        margin: 12px 0 14px;
        padding: 4px;
        border-radius: 16px;
        background: rgba(255, 255, 255, 0.06);
      }
      .gg-tab-btn {
        border: none;
        border-radius: 12px;
        padding: 8px 4px;
        font-size: 11px;
        font-weight: 600;
        color: ${theme.textMuted};
        background: transparent;
        cursor: pointer;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .gg-tab-btn[data-active="true"] {
        background: ${theme.accent};
        color: ${theme.accentText};
      }

      .gg-theme-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px;
        margin-bottom: 12px;
      }
      .gg-theme-chip {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 10px 12px;
        border-radius: 16px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: ${theme.textMain};
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        text-align: left;
      }
      .gg-theme-chip[data-active="true"] {
        border-color: ${theme.accent};
        background: ${theme.accentSoft};
      }

      .gg-btn-primary {
        width: 100%;
        border: none;
        border-radius: 18px;
        padding: 12px 16px;
        font-size: 13px;
        font-weight: 700;
        background: ${theme.accent};
        color: ${theme.accentText};
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
      }

      .gg-dl-btn {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        margin: 6px 12px 10px;
        padding: 7px 14px;
        border-radius: 14px;
        border: 1px solid ${theme.panelBorder};
        background: ${theme.panelBg};
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        color: ${theme.textMain};
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
      }

      #gg-pet {
        position: fixed;
        bottom: 66px;
        left: 12px;
        z-index: 2147483645;
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
        cursor: pointer;
        user-select: none;
        -webkit-tap-highlight-color: transparent;
      }
      #gg-pet-bubble {
        max-width: 180px;
        padding: 6px 10px;
        border-radius: 14px;
        background: ${theme.panelBg};
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid ${theme.panelBorder};
        color: ${theme.textMain};
        font-size: 11px;
        font-weight: 600;
        opacity: 0;
        transform: translateY(4px);
        transition: opacity 0.2s ease, transform 0.2s ease;
        pointer-events: none;
      }
      #gg-pet-bubble.gg-show {
        opacity: 1;
        transform: translateY(0);
      }
      @keyframes ggBob {
        0%, 100% { transform: translateY(0px); }
        50% { transform: translateY(-5px); }
      }
      #gg-pet-body {
        width: 54px;
        height: 54px;
        border-radius: 20px;
        background: ${theme.panelBg};
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid ${theme.panelBorder};
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 10px 24px rgba(0, 0, 0, 0.35);
        animation: ggBob 2.8s ease-in-out infinite;
      }

      #gg-game-overlay {
        position: fixed;
        inset: 0;
        z-index: 2147483647;
        background: rgba(4, 10, 18, 0.88);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        display: none;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 14px;
        color: ${theme.textMain};
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        touch-action: none;
      }
      #gg-game-overlay.gg-open {
        display: flex;
      }

      .gg-textarea {
        width: 100%;
        min-height: 96px;
        border-radius: 14px;
        border: 1px solid rgba(255,255,255,0.14);
        background: rgba(0,0,0,0.35);
        color: ${theme.textMain};
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        font-size: 12px;
        padding: 10px;
        box-sizing: border-box;
        resize: vertical;
      }
      .gg-input {
        width: 100%;
        border-radius: 12px;
        border: 1px solid rgba(255,255,255,0.14);
        background: rgba(0,0,0,0.35);
        color: ${theme.textMain};
        font-size: 12px;
        padding: 9px 12px;
        box-sizing: border-box;
        margin-bottom: 8px;
      }
    `;
  }

  function showModToast(msg) {
    if (window.GuardiangramBridge && typeof window.GuardiangramBridge.showToast === "function") {
      window.GuardiangramBridge.showToast(msg);
      return;
    }
    let toast = document.getElementById("gg-toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.id = "gg-toast";
      toast.style.cssText =
        "position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:2147483647;padding:10px 16px;border-radius:16px;background:var(--gg-panel-bg);border:1px solid var(--gg-panel-border);color:var(--gg-text-main);font-size:12px;font-weight:600;backdrop-filter:blur(16px);pointer-events:none;transition:opacity 0.2s ease;";
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = "1";
    clearTimeout(window.__ggToastTimer);
    window.__ggToastTimer = setTimeout(() => {
      toast.style.opacity = "0";
    }, 2200);
  }

  function triggerDownload(url, filename) {
    if (!url) {
      showModToast("Медиафайл не найден");
      return;
    }

    if (url.startsWith("blob:")) {
      fetch(url)
        .then((res) => res.blob())
        .then((blob) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const dataUrl = String(reader.result || "");
            if (window.GuardiangramBridge && window.GuardiangramBridge.downloadBase64) {
              window.GuardiangramBridge.downloadBase64(dataUrl, filename);
            } else {
              const a = document.createElement("a");
              a.href = dataUrl;
              a.download = filename;
              a.click();
              showModToast("Сохранено: " + filename);
            }
          };
          reader.readAsDataURL(blob);
        })
        .catch(() => showModToast("Не удалось выгрузить blob-файл"));
      return;
    }

    if (window.GuardiangramBridge && typeof window.GuardiangramBridge.downloadMedia === "function") {
      window.GuardiangramBridge.downloadMedia(url, filename);
    } else {
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.target = "_blank";
      document.body.appendChild(a);
      a.click();
      a.remove();
      showModToast("Загрузка: " + filename);
    }
  }

  function getBestImageUrl(img) {
    if (!img) return "";
    const srcset = img.getAttribute("srcset");
    if (srcset) {
      let bestUrl = "";
      let bestW = 0;
      srcset.split(",").forEach((entry) => {
        const parts = entry.trim().split(/\s+/);
        const w = parseInt(parts[1] || "0", 10);
        if (parts[0] && w >= bestW) {
          bestW = w;
          bestUrl = parts[0];
        }
      });
      if (bestUrl) return bestUrl;
    }
    return img.currentSrc || img.src || "";
  }

  function sweepAds() {
    const articles = document.querySelectorAll("article, [data-gg-post='true']");
    articles.forEach((article) => {
      if (!settings.hideAds) {
        if (article.getAttribute("data-gg-ad-hidden") === "true") {
          article.style.display = "";
          article.removeAttribute("data-gg-ad-hidden");
        }
        return;
      }

      const text = (article.innerText || "").toLowerCase();
      const hasAdLabel =
        article.getAttribute("data-gg-sponsored") === "true" ||
        /\b(реклама|sponsored|paid partnership|рекомендовано для вас)\b/i.test(text);

      if (hasAdLabel) {
        article.style.display = "none";
        article.setAttribute("data-gg-ad-hidden", "true");
      }
    });
  }

  function sweepDownloadButtons() {
    const posts = document.querySelectorAll("article, [data-gg-post='true']");
    posts.forEach((post, idx) => {
      if (post.getAttribute("data-gg-ad-hidden") === "true") return;
      const existing = post.querySelector(".gg-dl-btn");
      if (!settings.downloadButtons) {
        if (existing) existing.remove();
        return;
      }
      if (existing) return;

      const video = post.querySelector("video");
      const imgs = Array.from(post.querySelectorAll("img")).filter((im) => {
        const w = im.naturalWidth || im.clientWidth || 0;
        const alt = (im.getAttribute("alt") || "").toLowerCase();
        return !alt.includes("профил") && !alt.includes("profile") && w >= 120;
      });
      const targetImg = imgs[0] || post.querySelector("img[data-gg-media='true']");
      if (!video && !targetImg) return;

      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "gg-dl-btn";
      btn.innerHTML = `<span>⬇</span><span>Скачать ${video ? "видео" : "фото"}</span>`;
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (video) {
          const sourceEl = video.querySelector("source");
          const vUrl = video.currentSrc || video.src || (sourceEl && sourceEl.src) || "";
          triggerDownload(vUrl, `guardiangram_video_${Date.now()}_${idx}.mp4`);
        } else if (targetImg) {
          const iUrl = getBestImageUrl(targetImg);
          triggerDownload(iUrl, `guardiangram_photo_${Date.now()}_${idx}.jpg`);
        }
      });

      post.appendChild(btn);
    });
  }

  function replaceMuseWithGuardian(root = document.body) {
    if (!settings.museReplacer || !root) return;

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const toUpdate = [];
    let node;
    while ((node = walker.nextNode())) {
      if (node.parentElement && node.parentElement.closest("#gg-modal-backdrop")) continue;
      if (/\bMuse\b|Мьюз/i.test(node.nodeValue || "")) {
        toUpdate.push(node);
      }
    }
    toUpdate.forEach((txtNode) => {
      txtNode.nodeValue = txtNode.nodeValue.replace(/\bMuse\b|Мьюз/gi, "Страж");
    });

    const avatarSrc = getGuardianAvatarSrc();
    const imgs = root.querySelectorAll("img");
    imgs.forEach((img) => {
      const alt = img.getAttribute("alt") || "";
      const isMuseAttr =
        /\b(Muse|Мьюз|Страж)\b/i.test(alt) || img.getAttribute("data-gg-muse-avatar") === "true";
      const rowText = img.closest("div, li, a")?.textContent || "";
      const isMuseRow = /\b(Muse|Мьюз|Страж)\b/i.test(rowText) && (img.clientWidth <= 80 || img.hasAttribute("data-gg-muse-avatar"));

      if (isMuseAttr || isMuseRow) {
        if (alt) img.setAttribute("alt", alt.replace(/\bMuse\b|Мьюз/gi, "Страж"));
        if (img.src !== avatarSrc) {
          img.src = avatarSrc;
          img.removeAttribute("srcset");
          img.setAttribute("data-gg-avatar", "true");
        }
      }
    });
  }

  const seenDirectMessages = new Map();
  let lastThreadKey = "";

  function scanDirectMessages() {
    if (!settings.dmLogger) return;
    const isDirect =
      location.pathname.includes("/direct") || Boolean(document.querySelector("[data-gg-direct='true']"));
    if (!isDirect) {
      seenDirectMessages.clear();
      return;
    }

    const threadKey = location.pathname;
    if (threadKey !== lastThreadKey) {
      seenDirectMessages.clear();
      lastThreadKey = threadKey;
    }

    const msgNodes = document.querySelectorAll(
      '[data-gg-dm-id], div[role="row"] div[dir="auto"], div[role="gridcell"] div[dir="auto"]'
    );
    const activeIds = new Set();

    msgNodes.forEach((el, index) => {
      if (el.closest("#gg-modal-backdrop")) return;
      const msgId =
        el.getAttribute("data-gg-dm-id") ||
        el.getAttribute("id") ||
        `dm_${index}_${(el.textContent || "").slice(0, 24)}`;
      const text = (el.textContent || "").trim();
      if (!text) return;

      const isUnsentMarker = /сообщение отменено|message unsent|unsent a message/i.test(text);
      const prev = seenDirectMessages.get(msgId);

      if (isUnsentMarker && prev && !prev.logged) {
        prev.logged = true;
        recordDeletedDm(prev.sender, prev.text);
      } else if (!isUnsentMarker) {
        activeIds.add(msgId);
        if (!seenDirectMessages.has(msgId)) {
          const sender =
            el.getAttribute("data-gg-sender") ||
            el.closest("[data-gg-sender]")?.getAttribute("data-gg-sender") ||
            "Собеседник";
          seenDirectMessages.set(msgId, {
            id: msgId,
            sender,
            text,
            el,
            logged: false,
          });
        }
      }
    });

    seenDirectMessages.forEach((entry, id) => {
      if (!entry.logged && entry.el && !document.body.contains(entry.el) && !activeIds.has(id)) {
        entry.logged = true;
        recordDeletedDm(entry.sender, entry.text);
      }
    });
  }

  function recordDeletedDm(sender, text) {
    const logs = loadDmLogs();
    const now = new Date().toLocaleTimeString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
    logs.unshift({
      id: Date.now() + "_" + Math.random().toString(16).slice(2, 6),
      sender: sender || "Собеседник",
      text,
      time: now,
    });
    saveDmLogs(logs);
    renderDmLogList();
    showModToast("Поймано удалённое сообщение в Директе");
  }

  function runAutorunCustomScripts() {
    const scripts = loadScripts();
    scripts.forEach((item) => {
      if (item.autorun && item.code) {
        try {
          new Function(item.code)();
        } catch (err) {
          console.warn("Guardiangram MargyCode autorun error:", err);
        }
      }
    });
  }

  function ensureFloatingButton() {
    if (document.getElementById("gg-fab")) return;
    const fab = document.createElement("button");
    fab.id = "gg-fab";
    fab.type = "button";
    fab.title = "Guardiangram Настройки";
    fab.innerHTML = cowHatSvg(30);
    fab.addEventListener("click", () => {
      openModal();
    });
    document.body.appendChild(fab);
  }

  const PET_PHRASES = [
    "Страж на посту!",
    "Маме тёплый привет ✨",
    "Реклама под контролем",
    "Шляпа с коровьим принтом — топ!",
    "Сыграем в Block Blast?",
  ];

  function ensureMiniPet() {
    let pet = document.getElementById("gg-pet");
    if (!settings.miniPet) {
      if (pet) pet.remove();
      return;
    }
    if (pet) return;

    pet = document.createElement("div");
    pet.id = "gg-pet";
    pet.innerHTML = `
      <div id="gg-pet-bubble">Страж на посту!</div>
      <div id="gg-pet-body" style="padding:0;overflow:hidden;">
        <img src="${getGuardianAvatarSrc()}" alt="Страж" style="width:100%;height:100%;object-fit:cover;display:block;pointer-events:none;" />
      </div>
    `;

    let phraseIdx = 0;
    pet.addEventListener("click", () => {
      const bubble = document.getElementById("gg-pet-bubble");
      if (!bubble) return;
      phraseIdx = (phraseIdx + 1) % PET_PHRASES.length;
      bubble.textContent = PET_PHRASES[phraseIdx];
      bubble.classList.add("gg-show");
      clearTimeout(window.__ggPetTimer);
      window.__ggPetTimer = setTimeout(() => {
        bubble.classList.remove("gg-show");
      }, 2400);
    });

    document.body.appendChild(pet);
  }

  let activeTab = "appearance";

  function ensureModal() {
    if (document.getElementById("gg-modal-backdrop")) return;

    const backdrop = document.createElement("div");
    backdrop.id = "gg-modal-backdrop";
    backdrop.innerHTML = `
      <div id="gg-modal-sheet" role="dialog" aria-label="Guardiangram">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;">
          <div style="display:flex;align-items:center;gap:10px;">
            ${cowHatSvg(32)}
            <div>
              <div style="font-size:17px;font-weight:800;letter-spacing:-0.01em;">Guardiangram</div>
              <div style="font-size:11px;color:var(--gg-text-muted);">Material You · Liquid Glass</div>
            </div>
          </div>
          <button id="gg-close-btn" type="button" style="border:none;width:34px;height:34px;border-radius:12px;background:rgba(255,255,255,0.1);color:var(--gg-text-main);font-size:16px;font-weight:700;cursor:pointer;">✕</button>
        </div>

        <div class="gg-tabs">
          <button class="gg-tab-btn" data-tab="appearance" data-active="true" type="button">Оформление</button>
          <button class="gg-tab-btn" data-tab="features" type="button">Функции</button>
          <button class="gg-tab-btn" data-tab="dmlog" type="button">Директ</button>
          <button class="gg-tab-btn" data-tab="margycode" type="button">MargyCode</button>
        </div>

        <div id="gg-panel-appearance">
          <div style="font-size:12px;font-weight:700;margin-bottom:8px;color:var(--gg-text-muted);">Цветовая тема</div>
          <div class="gg-theme-grid" id="gg-theme-grid"></div>
          <div id="gg-appearance-toggles"></div>
          <button id="gg-open-game-btn" type="button" class="gg-btn-primary" style="margin-top:10px;">
            <span>🧩</span>
            <span>Открыть Block Blast (8×8)</span>
          </button>
        </div>

        <div id="gg-panel-features" style="display:none;">
          <div id="gg-features-toggles"></div>
        </div>

        <div id="gg-panel-dmlog" style="display:none;">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
            <span style="font-size:12px;font-weight:700;color:var(--gg-text-muted);">Удалённые сообщения в Директе</span>
            <button id="gg-clear-dmlog" type="button" style="border:none;background:rgba(255,255,255,0.1);color:var(--gg-text-main);border-radius:10px;padding:5px 10px;font-size:11px;font-weight:600;cursor:pointer;">Очистить</button>
          </div>
          <div id="gg-dmlog-list" style="max-height:240px;overflow-y:auto;"></div>
        </div>

        <div id="gg-panel-margycode" style="display:none;">
          <div style="font-size:12px;font-weight:700;margin-bottom:8px;color:var(--gg-text-muted);">Пользовательские JS-скрипты (MargyCode)</div>
          <input id="gg-script-name" class="gg-input" type="text" placeholder="Название скрипта (например: Крупный шрифт)" />
          <textarea id="gg-script-code" class="gg-textarea" placeholder="document.body.style.fontSize = '17px';"></textarea>
          <label style="display:flex;align-items:center;gap:8px;font-size:12px;margin:8px 0;cursor:pointer;">
            <input id="gg-script-autorun" type="checkbox" checked />
            <span>Автозапуск при открытии страницы</span>
          </label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px;">
            <button id="gg-script-run" type="button" class="gg-btn-primary">Выполнить</button>
            <button id="gg-script-save" type="button" style="border:1px solid var(--gg-panel-border);background:rgba(255,255,255,0.08);color:var(--gg-text-main);border-radius:18px;padding:12px;font-size:13px;font-weight:700;cursor:pointer;">Сохранить</button>
          </div>
          <div id="gg-script-output" style="font-size:11px;color:var(--gg-accent);margin-bottom:8px;"></div>
          <div id="gg-scripts-list" style="max-height:150px;overflow-y:auto;"></div>
        </div>

        <div style="margin-top:14px;padding-top:12px;border-top:1px solid rgba(255,255,255,0.1);text-align:center;font-size:11px;color:var(--gg-text-muted);">
          Guardiangram • Вдохновлено The Guardian из Slendytubbies (ZeoWorks)
        </div>
      </div>
    `;

    backdrop.addEventListener("click", (e) => {
      if (e.target === backdrop) closeModal();
    });

    document.body.appendChild(backdrop);

    document.getElementById("gg-close-btn").addEventListener("click", closeModal);
    document.getElementById("gg-open-game-btn").addEventListener("click", () => {
      closeModal();
      openBlockBlast();
    });

    document.querySelectorAll(".gg-tab-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        activeTab = btn.getAttribute("data-tab");
        renderModalState();
      });
    });

    document.getElementById("gg-clear-dmlog").addEventListener("click", () => {
      saveDmLogs([]);
      renderDmLogList();
    });

    document.getElementById("gg-script-run").addEventListener("click", () => {
      const code = document.getElementById("gg-script-code").value;
      const out = document.getElementById("gg-script-output");
      try {
        new Function(code)();
        out.textContent = "Скрипт выполнен успешно";
      } catch (err) {
        out.textContent = "Ошибка: " + err.message;
      }
    });

    document.getElementById("gg-script-save").addEventListener("click", () => {
      const nameInput = document.getElementById("gg-script-name");
      const codeInput = document.getElementById("gg-script-code");
      const autorunInput = document.getElementById("gg-script-autorun");
      const name = nameInput.value.trim() || "Скрипт #" + (loadScripts().length + 1);
      const code = codeInput.value.trim();
      if (!code) return;
      const scripts = loadScripts();
      scripts.unshift({
        id: Date.now().toString(),
        name,
        code,
        autorun: Boolean(autorunInput.checked),
      });
      saveScripts(scripts);
      nameInput.value = "";
      renderScriptsList();
      document.getElementById("gg-script-output").textContent = "Сохранено: " + name;
    });

    renderModalState();
  }

  function makeToggleRow(label, desc, key) {
    const row = document.createElement("div");
    row.className = "gg-row";
    row.innerHTML = `
      <div>
        <div style="font-size:13px;font-weight:700;">${label}</div>
        <div style="font-size:11px;color:var(--gg-text-muted);">${desc}</div>
      </div>
      <button type="button" class="gg-switch" data-on="${Boolean(settings[key])}"></button>
    `;
    row.querySelector(".gg-switch").addEventListener("click", () => {
      settings[key] = !settings[key];
      saveSettings(settings);
      refreshAllEffects();
      renderModalState();
    });
    return row;
  }

  function renderModalState() {
    document.querySelectorAll(".gg-tab-btn").forEach((btn) => {
      btn.setAttribute("data-active", String(btn.getAttribute("data-tab") === activeTab));
    });

    ["appearance", "features", "dmlog", "margycode"].forEach((tab) => {
      const panel = document.getElementById("gg-panel-" + tab);
      if (panel) panel.style.display = tab === activeTab ? "block" : "none";
    });

    const themeGrid = document.getElementById("gg-theme-grid");
    if (themeGrid) {
      themeGrid.innerHTML = "";
      Object.entries(THEMES).forEach(([key, t]) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "gg-theme-chip";
        chip.setAttribute("data-active", String(settings.theme === key));
        chip.innerHTML = `
          <span style="width:14px;height:14px;border-radius:50%;background:${t.accent};flex-shrink:0;border:1px solid rgba(255,255,255,0.4);"></span>
          <span>${t.name}</span>
        `;
        chip.addEventListener("click", () => {
          settings.theme = key;
          saveSettings(settings);
          refreshAllEffects();
          renderModalState();
        });
        themeGrid.appendChild(chip);
      });
    }

    const appToggles = document.getElementById("gg-appearance-toggles");
    if (appToggles) {
      appToggles.innerHTML = "";
      appToggles.appendChild(
        makeToggleRow("Матовое стекло", "Liquid Glass blur(16px) для панелей", "liquidGlass")
      );
      appToggles.appendChild(
        makeToggleRow("Рамка вокруг аватарок", "Цветной контур Material You", "avatarFrames")
      );
      appToggles.appendChild(
        makeToggleRow("Мини-питомец Страж", "Интерактивный Страж в углу экрана", "miniPet")
      );
    }

    const featToggles = document.getElementById("gg-features-toggles");
    if (featToggles) {
      featToggles.innerHTML = "";
      featToggles.appendChild(
        makeToggleRow("Скрывать рекламу", "Убирает посты «Реклама» и «Sponsored»", "hideAds")
      );
      featToggles.appendChild(
        makeToggleRow("Кнопка скачивания", "Кнопка сохранения под фото и видео", "downloadButtons")
      );
      featToggles.appendChild(
        makeToggleRow("Логгер Директа", "Сохраняет удалённые сообщения", "dmLogger")
      );
      featToggles.appendChild(
        makeToggleRow("Muse → Страж", "Подменяет имя и аватар нейросети", "museReplacer")
      );
    }

    renderDmLogList();
    renderScriptsList();
  }

  function renderDmLogList() {
    const list = document.getElementById("gg-dmlog-list");
    if (!list) return;
    const logs = loadDmLogs();
    if (!logs.length) {
      list.innerHTML = `<div style="padding:18px;text-align:center;font-size:12px;color:var(--gg-text-muted);">Пока нет перехваченных удалённых сообщений. Откройте Директ — логгер работает автоматически.</div>`;
      return;
    }
    list.innerHTML = "";
    logs.forEach((item) => {
      const row = document.createElement("div");
      row.className = "gg-row";
      row.style.flexDirection = "column";
      row.style.alignItems = "flex-start";
      row.innerHTML = `
        <div style="display:flex;width:100%;justify-content:space-between;font-size:11px;color:var(--gg-accent);font-weight:700;">
          <span>${escapeHtml(item.sender)}</span>
          <span>${escapeHtml(item.time)}</span>
        </div>
        <div style="font-size:13px;word-break:break-word;">${escapeHtml(item.text)}</div>
      `;
      list.appendChild(row);
    });
  }

  function renderScriptsList() {
    const list = document.getElementById("gg-scripts-list");
    if (!list) return;
    const scripts = loadScripts();
    if (!scripts.length) {
      list.innerHTML = `<div style="font-size:11px;color:var(--gg-text-muted);text-align:center;padding:8px;">Сохранённых скриптов пока нет</div>`;
      return;
    }
    list.innerHTML = "";
    scripts.forEach((item) => {
      const row = document.createElement("div");
      row.className = "gg-row";
      row.innerHTML = `
        <div style="min-width:0;flex:1;">
          <div style="font-size:12px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(item.name)}</div>
          <div style="font-size:10px;color:var(--gg-text-muted);">${item.autorun ? "Автозапуск включён" : "Ручной запуск"}</div>
        </div>
        <div style="display:flex;gap:6px;">
          <button type="button" data-act="run" style="border:none;border-radius:10px;padding:6px 10px;font-size:11px;font-weight:700;background:var(--gg-accent);color:var(--gg-accent-text);cursor:pointer;">▶</button>
          <button type="button" data-act="del" style="border:none;border-radius:10px;padding:6px 10px;font-size:11px;font-weight:700;background:rgba(255,255,255,0.12);color:var(--gg-text-main);cursor:pointer;">✕</button>
        </div>
      `;
      row.querySelector('[data-act="run"]').addEventListener("click", () => {
        try {
          new Function(item.code)();
          document.getElementById("gg-script-output").textContent = "Выполнено: " + item.name;
        } catch (err) {
          document.getElementById("gg-script-output").textContent = "Ошибка: " + err.message;
        }
      });
      row.querySelector('[data-act="del"]').addEventListener("click", () => {
        saveScripts(loadScripts().filter((s) => s.id !== item.id));
        renderScriptsList();
      });
      list.appendChild(row);
    });
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function openModal() {
    ensureModal();
    renderModalState();
    document.getElementById("gg-modal-backdrop").classList.add("gg-open");
  }

  function closeModal() {
    const backdrop = document.getElementById("gg-modal-backdrop");
    if (backdrop) backdrop.classList.remove("gg-open");
  }

  /* ================== BLOCK BLAST 8x8 ================== */
  const SHAPES = [
    [[1]],
    [[1, 1]],
    [[1], [1]],
    [[1, 1, 1]],
    [[1], [1], [1]],
    [[1, 1, 1, 1]],
    [[1], [1], [1], [1]],
    [[1, 1], [1, 1]],
    [[1, 1, 1], [1, 1, 1], [1, 1, 1]],
    [[1, 0], [1, 1]],
    [[0, 1], [1, 1]],
    [[1, 1], [1, 0]],
    [[1, 1], [0, 1]],
    [[1, 1, 1], [0, 1, 0]],
    [[1, 1, 0], [0, 1, 1]],
  ];

  const BLOCK_COLORS = ["#00E5FF", "#FF8FAB", "#10B981", "#F59E0B", "#A78BFA", "#38BDF8"];

  let gameState = null;

  function ensureBlockBlastOverlay() {
    if (document.getElementById("gg-game-overlay")) return;
    const overlay = document.createElement("div");
    overlay.id = "gg-game-overlay";
    overlay.innerHTML = `
      <div style="width:100%;max-width:390px;display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
        <div>
          <div style="font-size:18px;font-weight:800;">Block Blast</div>
          <div style="font-size:11px;color:var(--gg-text-muted);">С коровьим бонус-принтом (+50)</div>
        </div>
        <button id="gg-game-close" type="button" style="border:none;border-radius:14px;padding:8px 14px;background:rgba(255,255,255,0.12);color:var(--gg-text-main);font-size:12px;font-weight:700;cursor:pointer;">Закрыть</button>
      </div>
      <div style="width:100%;max-width:390px;display:flex;justify-content:space-between;padding:10px 14px;border-radius:18px;background:var(--gg-panel-bg);border:1px solid var(--gg-panel-border);margin-bottom:10px;font-variant-numeric:tabular-nums;">
        <div>
          <div style="font-size:10px;color:var(--gg-text-muted);">СЧЁТ</div>
          <div id="gg-bb-score" style="font-size:20px;font-weight:800;">0</div>
        </div>
        <div style="text-align:right;">
          <div style="font-size:10px;color:var(--gg-text-muted);">РЕКОРД</div>
          <div id="gg-bb-best" style="font-size:20px;font-weight:800;color:var(--gg-accent);">0</div>
        </div>
      </div>
      <canvas id="gg-bb-canvas" style="border-radius:22px;background:rgba(15,23,42,0.72);border:1px solid var(--gg-panel-border);touch-action:none;"></canvas>
      <div id="gg-bb-gameover" style="display:none;margin-top:10px;width:100%;max-width:390px;text-align:center;">
        <div style="font-size:15px;font-weight:800;margin-bottom:8px;">Нет доступных ходов!</div>
        <button id="gg-bb-restart" type="button" class="gg-btn-primary">Играть снова</button>
      </div>
    `;
    document.body.appendChild(overlay);

    document.getElementById("gg-game-close").addEventListener("click", () => {
      overlay.classList.remove("gg-open");
    });
    document.getElementById("gg-bb-restart").addEventListener("click", () => {
      initBlockBlastGame();
    });

    const canvas = document.getElementById("gg-bb-canvas");
    canvas.addEventListener("pointerdown", onCanvasPointerDown);
    window.addEventListener("pointermove", onCanvasPointerMove);
    window.addEventListener("pointerup", onCanvasPointerUp);
    window.addEventListener("pointercancel", onCanvasPointerUp);
  }

  function createRandomPiece() {
    const shape = SHAPES[Math.floor(Math.random() * SHAPES.length)];
    const isCowBonus = Math.random() < 0.14;
    const color = isCowBonus
      ? "#FFFFFF"
      : BLOCK_COLORS[Math.floor(Math.random() * BLOCK_COLORS.length)];
    return {
      shape,
      color,
      cow: isCowBonus,
      used: false,
    };
  }

  function initBlockBlastGame() {
    const best = parseInt(localStorage.getItem(STORAGE_KEY_BEST_SCORE) || "0", 10) || 0;
    const width = Math.min(window.innerWidth - 28, 380);
    const cell = Math.floor((width - 28) / 8);
    const boardPx = cell * 8;
    const padX = Math.floor((width - boardPx) / 2);
    const padY = 14;
    const trayTop = padY + boardPx + 18;
    const height = trayTop + cell * 3 + 22;

    gameState = {
      grid: Array.from({ length: 8 }, () => Array(8).fill(null)),
      tray: [createRandomPiece(), createRandomPiece(), createRandomPiece()],
      score: 0,
      best,
      width,
      height,
      cell,
      padX,
      padY,
      trayTop,
      drag: null,
      flashRows: [],
      flashCols: [],
      flashAlpha: 0,
    };

    document.getElementById("gg-bb-gameover").style.display = "none";
    updateScoreUi();
    resizeGameCanvas();
    drawGame();
  }

  function resizeGameCanvas() {
    const canvas = document.getElementById("gg-bb-canvas");
    if (!canvas || !gameState) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = gameState.width * dpr;
    canvas.height = gameState.height * dpr;
    canvas.style.width = gameState.width + "px";
    canvas.style.height = gameState.height + "px";
    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function updateScoreUi() {
    if (!gameState) return;
    if (gameState.score > gameState.best) {
      gameState.best = gameState.score;
      try {
        localStorage.setItem(STORAGE_KEY_BEST_SCORE, String(gameState.best));
      } catch (_) {}
    }
    const sEl = document.getElementById("gg-bb-score");
    const bEl = document.getElementById("gg-bb-best");
    if (sEl) sEl.textContent = String(gameState.score);
    if (bEl) bEl.textContent = String(gameState.best);
  }

  function canPlace(piece, row, col) {
    const h = piece.shape.length;
    const w = piece.shape[0].length;
    if (row < 0 || col < 0 || row + h > 8 || col + w > 8) return false;
    for (let r = 0; r < h; r++) {
      for (let c = 0; c < w; c++) {
        if (piece.shape[r][c] && gameState.grid[row + r][col + c]) {
          return false;
        }
      }
    }
    return true;
  }

  function hasAnyValidMove() {
    return gameState.tray.some((piece) => {
      if (piece.used) return false;
      for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
          if (canPlace(piece, r, c)) return true;
        }
      }
      return false;
    });
  }

  function placePiece(piece, row, col) {
    let blocksCount = 0;
    for (let r = 0; r < piece.shape.length; r++) {
      for (let c = 0; c < piece.shape[0].length; c++) {
        if (piece.shape[r][c]) {
          gameState.grid[row + r][col + c] = {
            color: piece.color,
            cow: piece.cow,
          };
          blocksCount++;
        }
      }
    }
    piece.used = true;
    gameState.score += blocksCount * (piece.cow ? 2 : 1);

    const fullRows = [];
    const fullCols = [];
    for (let r = 0; r < 8; r++) {
      if (gameState.grid[r].every(Boolean)) fullRows.push(r);
    }
    for (let c = 0; c < 8; c++) {
      let full = true;
      for (let r = 0; r < 8; r++) {
        if (!gameState.grid[r][c]) {
          full = false;
          break;
        }
      }
      if (full) fullCols.push(c);
    }

    let clearedCow = false;
    fullRows.forEach((r) => {
      for (let c = 0; c < 8; c++) {
        if (gameState.grid[r][c]?.cow) clearedCow = true;
        gameState.grid[r][c] = null;
      }
    });
    fullCols.forEach((c) => {
      for (let r = 0; r < 8; r++) {
        if (gameState.grid[r][c]?.cow) clearedCow = true;
        gameState.grid[r][c] = null;
      }
    });

    const lines = fullRows.length + fullCols.length;
    if (lines > 0) {
      gameState.score += lines * lines * 12 + (clearedCow ? 50 : 0);
      gameState.flashRows = fullRows;
      gameState.flashCols = fullCols;
      gameState.flashAlpha = 1;
      if (clearedCow) {
        showModToast("Коровий бонус! +50 очков");
      }
    }

    if (gameState.tray.every((p) => p.used)) {
      gameState.tray = [createRandomPiece(), createRandomPiece(), createRandomPiece()];
    }

    updateScoreUi();

    if (!hasAnyValidMove()) {
      document.getElementById("gg-bb-gameover").style.display = "block";
    }
  }

  function getTraySlotCenter(index) {
    const slotW = gameState.width / 3;
    return {
      x: slotW * index + slotW / 2,
      y: gameState.trayTop + gameState.cell * 1.35,
    };
  }

  function getPointerPos(e) {
    const canvas = document.getElementById("gg-bb-canvas");
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
  }

  function onCanvasPointerDown(e) {
    if (!gameState) return;
    const overlay = document.getElementById("gg-game-overlay");
    if (!overlay || !overlay.classList.contains("gg-open")) return;
    const pos = getPointerPos(e);
    if (pos.y < gameState.trayTop - 12) return;

    const slotIdx = Math.min(2, Math.max(0, Math.floor(pos.x / (gameState.width / 3))));
    const piece = gameState.tray[slotIdx];
    if (!piece || piece.used) return;

    const liftY = e.pointerType === "touch" ? 54 : 18;
    gameState.drag = {
      slotIdx,
      piece,
      x: pos.x,
      y: pos.y - liftY,
      liftY,
    };
    drawGame();
  }

  function onCanvasPointerMove(e) {
    if (!gameState || !gameState.drag) return;
    const pos = getPointerPos(e);
    gameState.drag.x = pos.x;
    gameState.drag.y = pos.y - gameState.drag.liftY;
    drawGame();
  }

  function onCanvasPointerUp() {
    if (!gameState || !gameState.drag) return;
    const { piece, x, y } = gameState.drag;
    const snap = getSnapGridCoords(piece, x, y);
    if (snap && canPlace(piece, snap.row, snap.col)) {
      placePiece(piece, snap.row, snap.col);
    }
    gameState.drag = null;
    drawGame();
  }

  function getSnapGridCoords(piece, centerX, centerY) {
    const h = piece.shape.length;
    const w = piece.shape[0].length;
    const pieceW = w * gameState.cell;
    const pieceH = h * gameState.cell;
    const topLeftX = centerX - pieceW / 2;
    const topLeftY = centerY - pieceH / 2;
    const col = Math.round((topLeftX - gameState.padX) / gameState.cell);
    const row = Math.round((topLeftY - gameState.padY) / gameState.cell);
    if (row >= -1 && col >= -1 && row <= 8 && col <= 8) {
      return { row, col };
    }
    return null;
  }

  function drawBlockCell(ctx, x, y, size, color, isCow, alpha = 1) {
    ctx.save();
    ctx.globalAlpha = alpha;
    const pad = 2;
    const rx = x + pad;
    const ry = y + pad;
    const rw = size - pad * 2;
    const rh = size - pad * 2;
    const r = Math.max(4, size * 0.2);

    ctx.beginPath();
    ctx.roundRect(rx, ry, rw, rh, r);
    ctx.fillStyle = color;
    ctx.fill();

    if (isCow) {
      ctx.clip();
      ctx.fillStyle = "#0F172A";
      ctx.beginPath();
      ctx.arc(rx + rw * 0.28, ry + rh * 0.3, rw * 0.18, 0, Math.PI * 2);
      ctx.arc(rx + rw * 0.72, ry + rh * 0.66, rw * 0.21, 0, Math.PI * 2);
      ctx.arc(rx + rw * 0.66, ry + rh * 0.24, rw * 0.12, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#FACC15";
      ctx.lineWidth = 2;
      ctx.strokeRect(rx + 1, ry + 1, rw - 2, rh - 2);
    } else {
      ctx.fillStyle = "rgba(255,255,255,0.22)";
      ctx.fillRect(rx + 3, ry + 2, rw - 6, Math.max(2, rh * 0.18));
    }
    ctx.restore();
  }

  function drawGame() {
    const canvas = document.getElementById("gg-bb-canvas");
    if (!canvas || !gameState) return;
    const ctx = canvas.getContext("2d");
    const { width, height, cell, padX, padY, grid, tray } = gameState;

    ctx.clearRect(0, 0, width, height);

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const x = padX + c * cell;
        const y = padY + r * cell;
        ctx.fillStyle = "rgba(255,255,255,0.06)";
        ctx.beginPath();
        ctx.roundRect(x + 2, y + 2, cell - 4, cell - 4, 6);
        ctx.fill();

        const filled = grid[r][c];
        if (filled) {
          drawBlockCell(ctx, x, y, cell, filled.color, filled.cow, 1);
        }
      }
    }

    if (gameState.drag) {
      const { piece, x, y } = gameState.drag;
      const snap = getSnapGridCoords(piece, x, y);
      if (snap && canPlace(piece, snap.row, snap.col)) {
        for (let r = 0; r < piece.shape.length; r++) {
          for (let c = 0; c < piece.shape[0].length; c++) {
            if (piece.shape[r][c]) {
              drawBlockCell(
                ctx,
                padX + (snap.col + c) * cell,
                padY + (snap.row + r) * cell,
                cell,
                piece.color,
                piece.cow,
                0.32
              );
            }
          }
        }
      }
    }

    tray.forEach((piece, idx) => {
      if (piece.used) return;
      if (gameState.drag && gameState.drag.slotIdx === idx) return;
      const miniCell = Math.floor(cell * 0.56);
      const center = getTraySlotCenter(idx);
      const pw = piece.shape[0].length * miniCell;
      const ph = piece.shape.length * miniCell;
      const startX = center.x - pw / 2;
      const startY = center.y - ph / 2;
      for (let r = 0; r < piece.shape.length; r++) {
        for (let c = 0; c < piece.shape[0].length; c++) {
          if (piece.shape[r][c]) {
            drawBlockCell(
              ctx,
              startX + c * miniCell,
              startY + r * miniCell,
              miniCell,
              piece.color,
              piece.cow,
              1
            );
          }
        }
      }
    });

    if (gameState.drag) {
      const { piece, x, y } = gameState.drag;
      const pw = piece.shape[0].length * cell;
      const ph = piece.shape.length * cell;
      const startX = x - pw / 2;
      const startY = y - ph / 2;
      for (let r = 0; r < piece.shape.length; r++) {
        for (let c = 0; c < piece.shape[0].length; c++) {
          if (piece.shape[r][c]) {
            drawBlockCell(
              ctx,
              startX + c * cell,
              startY + r * cell,
              cell,
              piece.color,
              piece.cow,
              0.95
            );
          }
        }
      }
    }
  }

  function openBlockBlast() {
    ensureBlockBlastOverlay();
    document.getElementById("gg-game-overlay").classList.add("gg-open");
    initBlockBlastGame();
  }

  /* ================== LIFECYCLE & OBSERVERS ================== */
  function refreshAllEffects() {
    applyThemeAndStyles();
    ensureFloatingButton();
    ensureMiniPet();
    sweepAds();
    sweepDownloadButtons();
    replaceMuseWithGuardian(document.body);
    scanDirectMessages();
  }

  window.__guardiangramRefresh = refreshAllEffects;

  let sweepScheduled = false;
  function scheduleSweep() {
    if (sweepScheduled) return;
    sweepScheduled = true;
    requestAnimationFrame(() => {
      sweepScheduled = false;
      sweepAds();
      sweepDownloadButtons();
      replaceMuseWithGuardian(document.body);
      scanDirectMessages();
    });
  }

  function boot() {
    if (!document.body) {
      setTimeout(boot, 50);
      return;
    }
    refreshAllEffects();
    runAutorunCustomScripts();

    const observer = new MutationObserver(() => {
      scheduleSweep();
    });
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
